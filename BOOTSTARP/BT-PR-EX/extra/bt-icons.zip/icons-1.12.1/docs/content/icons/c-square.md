---
title: C square
categories:
  - Shapes
tags:
  - copyright
---
