---
title: 0 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
added: 1.10.0
---
